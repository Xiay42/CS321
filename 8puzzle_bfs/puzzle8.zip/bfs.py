import puzzle8 as p8
from typing import List


def breadth_first_search(state: int) -> List[int]:
    """Finds path to solution via breadth-first search. Returns a list of
    squares that the blank moves to in order to get to solution.
    """
    raise NotImplementedError("You must implement this method")

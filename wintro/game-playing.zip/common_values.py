# Constant values used throughout the code
RED = 1
YELLOW = -1
EMPTY = 0
RED_MARKER = "R"
YELLOW_MARKER = "Y"
COLOR_NAMES = {RED: "red", YELLOW: "yellow"}
MAX_PLAYER = 1
MIN_PLAYER = -1
PLAYER_1 = 1
PLAYER_2 = -1
MARKERS = {RED: "R", YELLOW: "Y"}
